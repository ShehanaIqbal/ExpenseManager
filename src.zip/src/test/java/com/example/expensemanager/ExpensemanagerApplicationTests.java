package com.example.expensemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpensemanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
