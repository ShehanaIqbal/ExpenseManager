package com.example.expensemanager.constants;

public class Roles {
    public static final String ROLE_ADMIN = "Admin";
    public static final String ROLE_USER = "User";
}
